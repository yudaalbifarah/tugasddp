from Animal import Animal  # Pastikan file `Animal.py` ada di lokasi yang sama

class Bird(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, warna, paruh):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.warna = warna
        self.paruh = paruh

    # Method
    def info_bird(self):
        print('Warna\t: ', self.warna, '\nJenis Paruh\t: ', self.paruh)

# Membuat objek dari Bird
bird = Bird('Elang', 'Daging', 'Di tebing', 'Bertelur', 'Coklat', 'Bengkok dan Lancip')
print('## Info Bird ##')
bird.info_animal()  # Memanggil method dari parent class
bird.info_bird()    # Memanggil method dari class Bird
