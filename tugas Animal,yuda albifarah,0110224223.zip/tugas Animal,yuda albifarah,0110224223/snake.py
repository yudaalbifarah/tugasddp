from Animal import Animal 

class Snake(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, panjang, berbisa):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.panjang = panjang 
        self.berbisa = berbisa 

    def info_snake(self):
         print('Panjang\t: ', self.panjang, '\nBerbisa\t: ', self.berbisa)
             
snake = Snake('Python', 'Daging', 'dihutan', 'Bertelur', '5 meter', 'tidak')
print('## Info Snake ##')
snake.info_animal() 
snake.info_snake()   