from Animal import Animal

class Fish(Animal):
    def __init__(self, nama, makanan, hidup, berkembang_biak, bernapas, habitat):
        super().__init__(nama, makanan, hidup, berkembang_biak)
        self.bernapas = bernapas
        self.habitat = habitat

    # Method
    def info_fish(self):
        print('Bernapas\t: ', self.bernapas, '\nHabitat\t\t: ', self.habitat)

# Objek
print()

fish = Fish('Hiu', 'Daging', 'Laut', 'Melahirkan', 'Insang', 'Air Asin')
print('## Info Fish ##')
fish.info_animal()  # Memanggil metode dari parent class
fish.info_fish()    # Memanggil metode dari class Fish
