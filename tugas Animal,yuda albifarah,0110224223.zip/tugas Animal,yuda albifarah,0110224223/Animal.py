class Animal:
    # Konstruktor Properti
    def __init__(self, nama, makanan, hidup, berkembang_biak):
        self.nama = nama
        self.makanan = makanan
        self.hidup = hidup
        self.berkembang_biak = berkembang_biak

    # Method
    def info_animal(self):
        print('Nama Hewan\t\t: ', self.nama)
        print('Makanan\t\t\t: ', self.makanan)
        print('Hidup\t\t\t: ', self.hidup)
        print('Berkembang Biak\t: ', self.berkembang_biak)

# Objek
kucing = Animal('kucing', 'daging', 'hidup', 'melahirkan')
kucing.info_animal()
